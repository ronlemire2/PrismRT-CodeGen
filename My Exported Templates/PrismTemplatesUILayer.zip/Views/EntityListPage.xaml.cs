﻿using Microsoft.Practices.Prism.StoreApps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Views
{
    public sealed partial class EntityListPage : VisualStateAwarePage
    {
        public EntityListPage() {
            this.InitializeComponent();
        }
    }
}
