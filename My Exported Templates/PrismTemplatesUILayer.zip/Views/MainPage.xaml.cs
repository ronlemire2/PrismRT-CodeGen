﻿using Microsoft.Practices.Prism.StoreApps;

namespace UILayer.Views
{
    public sealed partial class MainPage : VisualStateAwarePage
    {
        public MainPage() {
            this.InitializeComponent();
        }
    }
}
