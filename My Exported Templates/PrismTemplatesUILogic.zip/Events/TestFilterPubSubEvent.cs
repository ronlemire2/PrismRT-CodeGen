﻿using $safeprojectname$.Models;
using Microsoft.Practices.Prism.PubSubEvents;

namespace $safeprojectname$.Events
{
    public class TestFilterPubSubEvent : PubSubEvent<Entity>
    {
    }
}